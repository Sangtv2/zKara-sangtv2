//
//  singerTableViewController.swift
//  demoSqlite
//
//  Created by SOSO on 9/21/16.
//  Copyright © 2016 SANGTRIEU. All rights reserved.
//

import UIKit

class singerTableViewController: UITableViewController ,UISearchBarDelegate{
    var thamsoTruyen:NSUserDefaults!

    @IBOutlet weak var searchBar: UISearchBar!
    
    var mangAllSong:[String]!
    var mangid:[String]!
    var mangtext:[String]!
    var mangFulltext:[String]!
//    let autocompleTabeview = UITableView(frame: CGRectMake(0, 89, 320, 120), style: UITableViewStyle.Plain)
    
    var searchActive : Bool = false
    var filtered:[String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        
        thamsoTruyen = NSUserDefaults();
        
        let dong:String = thamsoTruyen.objectForKey("chon") as! String
        print(dong)
        
        mangid = []
        mangtext = []
        mangFulltext = []
        mangAllSong  = []
        
        let database:COpaquePointer = self.Data_Connect_DB_Sqlite("zkara", type: "sqlite")
        
        //table song_suggestion
        
                let statement:COpaquePointer = Data_Select("SELECT * FROM song_suggestion", database: database);
        
        while sqlite3_step(statement) == SQLITE_ROW {
            
            _ = Int(sqlite3_column_int(statement, 0))
            
            
            let rowData = sqlite3_column_text(statement, 0)
            if let s_id = String.fromCString(UnsafePointer<CChar>(rowData)){
                mangid.append(s_id)
            }
            let rowData1 = sqlite3_column_text(statement, 1)
            if let s_acronym = String.fromCString(UnsafePointer<CChar>(rowData1)){
                mangtext.append(s_acronym)
            }
            
            let rowData2 = sqlite3_column_text(statement, 2)
            if let s_fulltext = String.fromCString(UnsafePointer<CChar>(rowData2))
            {
                mangFulltext.append(s_fulltext)
            }
        }
        sqlite3_finalize(statement)
        sqlite3_close(database)
    }

    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(true, animated: true)
        searchActive = true
        tableView.reloadData()
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
        searchActive = false;
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(false, animated: true)
        searchBar.resignFirstResponder()
        searchActive = false;
        tableView.reloadData()
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(false, animated: true)
        searchBar.resignFirstResponder()
        tableView.allowsMultipleSelection = true
        tableView.scrollEnabled = true
        searchActive = false
        tableView.reloadData()
    }
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        
        let searchBarRect = CGRect(x: 10, y: 10, width: self.view.bounds.size.width/2, height: 44)
        self.searchBar = UISearchBar(frame: searchBarRect)
        
        filtered = mangFulltext.filter({ (text) -> Bool in
            let tmp: NSString = text
            let range = tmp.rangeOfString(searchText, options: NSStringCompareOptions.CaseInsensitiveSearch)
            return range.location != NSNotFound
        })
        if(filtered.count == 0){
            searchActive = false;
//            self.searchBar.hidden = false
        } else {
            searchActive = true;
//            self.searchBar.hidden = true
        }
        self.tableView.reloadData()
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(searchActive) {
            return filtered.count
        }
        return 0

    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as UITableViewCell
        if(searchActive){
            cell.textLabel?.text = filtered[indexPath.row]
        } 
            else {
//        cell.textLabel?.text = mangtext[indexPath.row]
        }
        return cell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        // Title
        let alertController = UIAlertController(title: nil, message: "Search Autocomple", preferredStyle: .ActionSheet)
        
        alertController.view.backgroundColor = UIColor.cyanColor()
        alertController.view.tintColor = UIColor.whiteColor()
        
        // Cancel
        let cancelAction = UIAlertAction(title: "Cancel", style: .Destructive) { (action) in
            
            tableView.deselectRowAtIndexPath(indexPath, animated: true)
            
        }
        
        alertController.addAction(cancelAction)
        self.presentViewController(alertController, animated: true) {
        }
        
        self.tableView.reloadData()

    }
    
    
    func Data_Select( query:String,   database:COpaquePointer)->COpaquePointer{
        var statement:COpaquePointer = nil
        sqlite3_prepare_v2(database, query, -1, &statement, nil)
        return statement
    }
    
    func Data_Query( sql:String,  database:COpaquePointer){
        var errMsg:UnsafeMutablePointer<Int8> = nil
        let result = sqlite3_exec(database, sql, nil, nil, &errMsg);
        if (result != SQLITE_OK) {
            sqlite3_close(database)
            print("Error!")
            return
        }
    }
    
    func Data_Connect_DB_Sqlite( dbName:String,  type:String)->COpaquePointer{
        var database:COpaquePointer = nil
        var dbPath:String = ""
        let documentsPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString
        let storePath : NSString = documentsPath.stringByAppendingPathComponent(dbName)
        let fileManager : NSFileManager = NSFileManager.defaultManager()
        dbPath = NSBundle.mainBundle().pathForResource(dbName , ofType:type)!
        do {
            try fileManager.copyItemAtPath(dbPath, toPath: storePath as String)
            
        } catch{
            let result = sqlite3_open(dbPath, &database)
            if result != SQLITE_OK {
                sqlite3_close(database)
                print("Failed to open database")
            }
        }
        return database
    }
}
