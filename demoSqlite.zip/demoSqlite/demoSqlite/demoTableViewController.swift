//
//  demoTableViewController.swift
//  demoSqlite
//
//  Created by SOSO on 9/20/16.
//  Copyright © 2016 SANGTRIEU. All rights reserved.
//

import UIKit

class demoTableViewController: UITableViewController {
    var mangkey:[String]!
    var mangid:[String]!
    var mangtext:[String]!
    var mangacronym:[String]!
    var mangtype:[String]!
    
    var mangAll:[String]!
    
    
    var thamsoTruyen:NSUserDefaults!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        thamsoTruyen = NSUserDefaults();
        mangkey = []
        mangid = []
        mangtext = []
        mangacronym = []
        mangtype = []
        mangAll = []
        //ket noi
        
        let database:COpaquePointer = self.Data_Connect_DB_Sqlite("zkara", type: "sqlite")
        
        //table song_suggestion
        
//        let statement:COpaquePointer = Data_Select("SELECT * FROM song_suggestion", database: database);
        let statement:COpaquePointer = Data_Select("SELECT * FROM singer_suggestion", database: database);
        
        while sqlite3_step(statement) == SQLITE_ROW {
            
            _ = Int(sqlite3_column_int(statement, 0))
            
            
            let rowData = sqlite3_column_text(statement, 0)
            if let s_id = String.fromCString(UnsafePointer<CChar>(rowData)){
                mangid.append(s_id)
            }
            let rowData1 = sqlite3_column_text(statement, 1)
            if let s_acronym = String.fromCString(UnsafePointer<CChar>(rowData1)){
                mangacronym.append(s_acronym)
            }
            
            let rowData2 = sqlite3_column_text(statement, 2)
            if let s_fulltext = String.fromCString(UnsafePointer<CChar>(rowData2))
            {
            mangtext.append(s_fulltext)
            }
            let rowData3 = sqlite3_column_text(statement, 3)
            if let singer_id = String.fromCString(UnsafePointer<CChar>(rowData3)){
                mangAll.append(singer_id)
            }
            let rowData4 = sqlite3_column_text(statement, 4)
            if let s_type = String.fromCString(UnsafePointer<CChar>(rowData4))
            {
                mangAll.append(s_type)
            }
            
        }
        sqlite3_finalize(statement)
        sqlite3_close(database)
    }
    
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mangid.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as UITableViewCell
        
        cell.textLabel?.text = mangtext[indexPath.row]
        cell.detailTextLabel?.text = mangacronym[indexPath.row]

        return cell
    }
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        // Title
        let alertController = UIAlertController(title: nil, message: "Search Autocomple", preferredStyle: .ActionSheet)
        
        alertController.view.backgroundColor = UIColor.cyanColor()
        alertController.view.tintColor = UIColor.whiteColor()
        
        // Cancel
        let cancelAction = UIAlertAction(title: "Cancel", style: .Destructive) { (action) in
            
            tableView.deselectRowAtIndexPath(indexPath, animated: true)
            
        }
        
        alertController.addAction(cancelAction)
        self.presentViewController(alertController, animated: true) {
        }
        
        
        self.tableView.reloadData()
        
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let indexPath = tableView.indexPathForSelectedRow
        let dong:Int! = indexPath?.row
        let idHang:String = mangid[dong]
        print(idHang)
        thamsoTruyen.setObject(idHang, forKey: "chon")
        
    }
    
    func Data_Select( query:String,   database:COpaquePointer)->COpaquePointer{
        var statement:COpaquePointer = nil
        sqlite3_prepare_v2(database, query, -1, &statement, nil)
        return statement
    }
    
    
    func Data_Query( sql:String,  database:COpaquePointer){
        var errMsg:UnsafeMutablePointer<Int8> = nil
        let result = sqlite3_exec(database, sql, nil, nil, &errMsg);
        if (result != SQLITE_OK) {
            sqlite3_close(database)
            print("Error!")
            return
        }
    }
    
    func Data_Connect_DB_Sqlite( dbName:String,  type:String)->COpaquePointer{
        var database:COpaquePointer = nil
        var dbPath:String = ""
        let documentsPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString
        let storePath : NSString = documentsPath.stringByAppendingPathComponent(dbName)
        let fileManager : NSFileManager = NSFileManager.defaultManager()
        dbPath = NSBundle.mainBundle().pathForResource(dbName , ofType:type)!
        do {
            try fileManager.copyItemAtPath(dbPath, toPath: storePath as String)
            
        } catch{
            let result = sqlite3_open(dbPath, &database)
            if result != SQLITE_OK {
                sqlite3_close(database)
                print("Failed to open database")
            }
        }
        return database
    }
    
    
}
