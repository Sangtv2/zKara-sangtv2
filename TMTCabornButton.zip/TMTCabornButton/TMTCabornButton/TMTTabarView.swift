//
//  TMTTabarView.swift
//  TMTCabornButton
//
//  Created by SOSO on 9/10/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import UIKit

class TMTTabarView: UIView {
    
    @IBOutlet weak var highlightedView: UIView!

    @IBOutlet var buttons: [UIButton]!
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
    
    override func layoutSubviews() {
        super.layoutSubviews()
        highlightedView.frame = CGRect(x: 0, y: 0, width: buttons[0].frame.width, height: 4)
        self.setNeedsLayout()

    }
    @IBAction func onClick(sender: UIButton) {
        UIView.animateWithDuration(0.2) { 
            self.highlightedView.frame = CGRect(x: sender.frame.origin.x, y: 0, width: sender.frame.width, height: 4)
        }
    }

}
