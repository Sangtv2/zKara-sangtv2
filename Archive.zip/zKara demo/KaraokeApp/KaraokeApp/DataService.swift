//
//  DataService.swift
//  KaraokeApp
//
//  Created by SOSO on 9/6/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import Foundation
import Alamofire
import MBProgressHUD

class DataService {
    
    func getVideo(fromUrl: String, handle: (dict: [NSDictionary]) -> [SongDetail])
    {
        Alamofire.request(.GET, fromUrl, parameters: nil)
            .responseJSON{ response in
                switch response.result {
                case .Success:
                    let statusCode: Int = response.response!.statusCode
                    
                    if statusCode == 200 {
                        guard let jsonString = response.result.value else {
                            return
                        }
                        if let songsDictionary = jsonString["items"] as? [NSDictionary] {
                            handle(dict: songsDictionary)
                        }
                    }else if statusCode == 404 {
                        print("chua co du lieu")
                    }else {
                        print( "loi cai gi day")
                    }
                    
                case .Failure:
                    print("loi cmnr")
                }
        }
    }
    // return JSON that use in many class.
//    func getCommonJSON(song: SongDetail) -> NSDictionary
    
    func getTopVideos() {
        let urlTop = "https://www.googleapis.com/youtube/v3/search?part=snippet&order=viewCount&maxResults=50&type=video&q=beat+intitle:karaoke&key=AIzaSyCojCp66RLS9OY8hOwnW0UWLNdC56z24Os"
        getVideo(urlTop, handle: getTopSongs)
    }
    
    func getSearchVideos(byUrl url: String, handleReviced:(dict: [NSDictionary]) -> [SongDetail]) {
        getVideo(url, handle: handleReviced)
    }

  
    
    func getFavourite() {
        
    }
    
    func getPlayQueueList() {
        
    }
    
    // Handle
    func getTopSongs(dicts: [NSDictionary]) -> [SongDetail]{
        var result : [SongDetail] = []

        for dict in dicts {
            let song = SongDetail(dict: dict)
            result.append(song)
        }
        NSNotificationCenter.defaultCenter().postNotificationName("getSongDetailSuccess", object: nil, userInfo: ["listTopSong": result])
        
        return result
    }

}