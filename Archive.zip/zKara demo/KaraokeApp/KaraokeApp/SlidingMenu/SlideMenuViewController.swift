//
//  SlideMenuViewController.swift
//
//  Created by SOSO on 7/29/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import UIKit
import Social

class SlideMenuViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var tableView: UITableView!
    let headerTitles = [" MENU "]

    var Array : [String] = ["Import","Gallery","Slideshow","Tools","Share","Send"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBarHidden = true
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.registerNib(UINib.init(nibName: "SlideMenuTableViewCell",
            bundle: nil), forCellReuseIdentifier: "SlideMenuTableViewCell")
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Array.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell: SlideMenuTableViewCell = tableView.dequeueReusableCellWithIdentifier("SlideMenuTableViewCell", forIndexPath: indexPath) as! SlideMenuTableViewCell
        
        cell.lblDetail.text = Array[indexPath.row]
        cell.imageV.image = UIImage(named: "\(Array[indexPath.row])")
        
        return cell
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let vw = UIView()
        vw.backgroundColor = UIColor.whiteColor()
        
        return vw
    }

    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
       
        let selectedCell = tableView.cellForRowAtIndexPath(indexPath)!
        
        selectedCell.backgroundColor = UIColor.whiteColor()
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let appdelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        
        switch (indexPath.row) {

        case 0:
            
            let aboutVC = QRCodeViewController(nibName: "QRCodeViewController", bundle: nil)
            let aboutNavi = UINavigationController(rootViewController : aboutVC)
            appdelegate.centerContainer?.centerViewController = aboutNavi
            appdelegate.centerContainer?.toggleDrawerSide(MMDrawerSide.Left, animated: true, completion: nil)
            
            break
            
        case 1:
            let appdelegate = UIApplication.sharedApplication().delegate as! AppDelegate
            let mainVC = KRMainViewController(nibName: "KRMainViewController", bundle: nil)
            let mainNavi = UINavigationController(rootViewController : mainVC)
            appdelegate.centerContainer?.centerViewController = mainNavi
            appdelegate.centerContainer?.toggleDrawerSide(MMDrawerSide.Left, animated: true, completion: nil)
            
            break
        case 2:
            let appdelegate = UIApplication.sharedApplication().delegate as! AppDelegate
            let mainVC = KRMainViewController(nibName: "KRMainViewController", bundle: nil)
            let mainNavi = UINavigationController(rootViewController : mainVC)
            appdelegate.centerContainer?.centerViewController = mainNavi
            appdelegate.centerContainer?.toggleDrawerSide(MMDrawerSide.Left, animated: true, completion: nil)
            break
        case 3:
            break
        case 4 :
            break
        default:
            break
            
            }
        
        }

}
