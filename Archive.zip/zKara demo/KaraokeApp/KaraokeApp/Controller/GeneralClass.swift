//
//  GeneralClass.swift
//  KaraokeApp
//
//  Created by SOSO on 8/28/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import Foundation


let height: CGFloat = 90

//let server = "L5aqo_eD5c8" //simul tivi
    let server = "966ae3654e6f8d84" //tivi

let device = "4A86B8F5-B1D6-4887-B7F3-21BCB641DEE2" //ip6
//let device = "4A86B8F5-B1D6-4887-B7F3-21BCB641DEE2" //ip6 simu
//let device = "C4615169-08D6-4A53-AFA6-5AB6EC147563" //ip4s simu
//let device = "87720962-EA99-4EE0-BCBF-A6764A3AF7EC" //ip5s simu
//let device = "7BADCA69-7247-45C0-A414-215EBBE8DE0C" //ip5
/** KR Serach  */
let apiKey = "AIzaSyB1UWPSS2uhXEoGFN_vJJYY9kjzJe_bC-o"
let keySearch = " Nhập tên ca khúc hoặc ca sĩ "
let message =  " Không tìm thấy nội dung ! "
let messagekn = " Kiểm tra kết nối mạng !"

/** KR Top */


let urlTopHD = "https://www.googleapis.com/youtube/v3/videos?key=AIzaSyCojCp66RLS9OY8hOwnW0UWLNdC56z24Os&fields=items(snippet(title,thumbnails),statistics,contentDetails)&part=snippet,statistics,contentDetails&id=qu_25HafHOk"


/** Title */

let MENU = " MENU SEARCH"
let MenuTop = " MENU TOP "
let MenuLike = " MENU LIKE "
let MenuQueue = " MENU PLAY QUEUE "

let addplaySong =  "Thêm Ca Khúc"
let addTop =  "Thêm Vào Đầu"
let Cancel = " Huỷ bỏ "
let Delete = "Xoá"
let null = ""
let likeVC = "likeVC"
let type = "type"

let play_queue_list = "play_queue_list"
let current_song_status = "current_song_status"

let titleCount = "Danh Sách Chờ "
let urlTitle = "https://www.youtube.com/watch?v="
let thumbImage = "http://img.youtube.com/vi/"
let playnow = "Phát Ngay"
let Futura = "Futura"
let like = "Yêu Thích"
let titles  = "title"
let jpg = "/0.jpg"
let menu = "menu"

let ic_arrow_right = "ic_arrow_right"
let ic_arrow_left = "ic_arrow_left"
let cancel = " ❌ "



