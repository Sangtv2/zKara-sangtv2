//
//  ExtensionUIView.swift
//  Tattoo Social
//
//  Created by SOSO on 7/29/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import UIKit

extension UIView {
    
    func moveToFrameWithAnimation(newFrame: CGRect, delay: NSTimeInterval, time: NSTimeInterval) {
        
        UIView.animateWithDuration(time, delay: delay, options: .CurveEaseOut, animations: {
            self.frame = newFrame
            }, completion:nil)
    }
    
    func fadeOut(time: NSTimeInterval, delay: NSTimeInterval) {
        UIView.animateWithDuration(time, delay: delay, options: UIViewAnimationOptions.CurveEaseIn, animations: {
            self.alpha = 0.0
            }, completion: {
                (finished: Bool) -> Void in
                if finished == true {
                    self.hidden = true
                }
        })
    }
    
    func fadeIn(time: NSTimeInterval, delay: NSTimeInterval) {
        
        self.alpha = 0
        self.hidden = false
        
        UIView.animateWithDuration(time, delay: delay, options: UIViewAnimationOptions.CurveEaseIn, animations: {
            self.alpha = 1.0
            }, completion: {
                (finished: Bool) -> Void in
                if finished == true {
                    
                }
        })
    }
    
    func showIndicator(indicatorStyle: UIActivityIndicatorViewStyle, blockColor: UIColor, alpha: CGFloat) {
        NSOperationQueue.mainQueue().addOperationWithBlock {
            
            for currentView in self.subviews {
                if currentView.tag == 9999 {
                    return
                }
            }
            
            let viewBlock = UIView()
            viewBlock.tag = 9999
            viewBlock.backgroundColor = blockColor
            viewBlock.alpha = alpha
            viewBlock.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)
            
            let indicator = UIActivityIndicatorView(activityIndicatorStyle: indicatorStyle)
            
            indicator.frame = CGRect(
                x: self.frame.width/2-25,
                y: self.frame.height/2-25,
                width: 50,
                height: 50)
            
            viewBlock.addSubview(indicator)
            self.addSubview(viewBlock)
            
            indicator.startAnimating()
        }
    }
    
    func showIndicator() {
        NSOperationQueue.mainQueue().addOperationWithBlock {
            
            for currentView in self.subviews {
                if currentView.tag == 9999 {
                    return
                }
            }
            
            
            let viewBlock = UIView()
            viewBlock.tag = 9999
            viewBlock.backgroundColor = UIColor.blackColor()
            viewBlock.alpha = 0.3
            viewBlock.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)
            viewBlock.layer.cornerRadius = self.layer.cornerRadius
            
            let indicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.White)
            
            indicator.frame = CGRect(
                x: self.frame.width/2-25,
                y: self.frame.height/2-25,
                width: 50,
                height: 50)
            
            viewBlock.addSubview(indicator)
            self.addSubview(viewBlock)
            
            indicator.startAnimating()
        }
    }
    
    func showIndicator(frame: CGRect) {
        let viewBlock = UIView()
        viewBlock.tag = 9999
        viewBlock.backgroundColor = UIColor.whiteColor()
        viewBlock.alpha = 0.8
        viewBlock.frame = frame
        
        let indicator = UIActivityIndicatorView(activityIndicatorStyle: .Gray)
        
        indicator.frame = CGRect(
            x: self.frame.width/2-25,
            y: self.frame.height/2-25,
            width: 50,
            height: 50)
        
        viewBlock.addSubview(indicator)
        self.addSubview(viewBlock)
        
        indicator.startAnimating()
    }
    
    func hideIndicator() {
        
        let indicatorView = self.viewWithTag(9999)
        indicatorView?.removeFromSuperview()
        
        for currentView in self.subviews {
            if currentView.tag == 9999 {
                let _view = currentView
                NSOperationQueue.mainQueue().addOperationWithBlock {
                    _view.removeFromSuperview()
                }
            }
        }
    }
    
    func makeRoundedConner(radius: CGFloat = 10) {
        self.layer.cornerRadius = radius
        self.clipsToBounds = true
    }
    
    func leadingMarginToView(view: UIView, commonParrentView: UIView, margin: CGFloat = 0) -> NSLayoutConstraint  {
        let constraint = NSLayoutConstraint(
            item: self, attribute: .Leading, relatedBy: .Equal,
            toItem: view, attribute: .Leading, multiplier: 1, constant: margin)
        
        commonParrentView.addConstraint(constraint)
        
        return constraint
    }
    
    func trailingMarginToView(view: UIView, commonParrentView: UIView, margin: CGFloat = 0) -> NSLayoutConstraint {
        let constraint = NSLayoutConstraint(
            item: self, attribute: .Trailing, relatedBy: .Equal,
            toItem: view, attribute: .Trailing, multiplier: 1, constant: margin)
        
        commonParrentView.addConstraint(constraint)
        return constraint
    }
    
    func addConstraintTopToBot(view: UIView, commonParrentView: UIView, margin: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(
            item: self, attribute: .Top, relatedBy: .Equal,
            toItem: view, attribute: .Bottom, multiplier: 1, constant: margin)
        
        commonParrentView.addConstraint(constraint)
        return constraint
    }
    
    func addConstraintBotToTop(view: UIView, commonParrentView: UIView, margin: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(
            item: self, attribute: .Bottom, relatedBy: .Equal,
            toItem: view, attribute: .Top, multiplier: 1, constant: margin)
        
        commonParrentView.addConstraint(constraint)
        return constraint
    }
    
    func botMarginToView(view: UIView, commonParrentView: UIView, margin: CGFloat = 0) -> NSLayoutConstraint {
        let constraint = NSLayoutConstraint(
            item: self, attribute: .Bottom, relatedBy: .Equal,
            toItem: view, attribute: .Bottom, multiplier: 1, constant: margin)
        
        commonParrentView.addConstraint(constraint)
        return constraint
    }
    
    func topMarginToView(view: UIView, commonParrentView: UIView, margin: CGFloat = 0) -> NSLayoutConstraint {
        //        self.setTranslatesAutoresizingMaskIntoConstraints(false)
        
        let constraint = NSLayoutConstraint(
            item: self, attribute: .Top, relatedBy: .Equal,
            toItem: view, attribute: .Top, multiplier: 1, constant: margin)
        
        commonParrentView.addConstraint(constraint)
        return constraint
    }
    
    
    func addWidthConstraint(parrentView: UIView, width: CGFloat) -> NSLayoutConstraint {
        let constraint = NSLayoutConstraint (item: self,
                                             attribute: NSLayoutAttribute.Width,
                                             relatedBy: NSLayoutRelation.Equal,
                                             toItem: nil,
                                             attribute: NSLayoutAttribute.NotAnAttribute,
                                             multiplier: 1,
                                             constant: width)
        parrentView.addConstraint(constraint)
        return constraint
    }
    
    func addHeightConstraint(parrentView: UIView, height: CGFloat) -> NSLayoutConstraint {
        let constraint = NSLayoutConstraint (item: self,
                                             attribute: NSLayoutAttribute.Height,
                                             relatedBy: NSLayoutRelation.Equal,
                                             toItem: nil,
                                             attribute: NSLayoutAttribute.NotAnAttribute,
                                             multiplier: 1,
                                             constant: height)
        parrentView.addConstraint(constraint)
        return constraint
    }
    
    func addConstraintLeftToRight(view: UIView, commonParrentView: UIView, margin: CGFloat = 0) -> NSLayoutConstraint {
        let constraint = NSLayoutConstraint (item: self,
                                             attribute: NSLayoutAttribute.Left,
                                             relatedBy: NSLayoutRelation.Equal,
                                             toItem: view,
                                             attribute: NSLayoutAttribute.Right,
                                             multiplier: 1,
                                             constant: margin)
        commonParrentView.addConstraint(constraint)
        return constraint
    }
    
    func addConstraintRightToLeft(view: UIView, commonParrentView: UIView, margin: CGFloat = 0) -> NSLayoutConstraint {
        let constraint = NSLayoutConstraint (item: self,
                                             attribute: NSLayoutAttribute.Right,
                                             relatedBy: NSLayoutRelation.Equal,
                                             toItem: view,
                                             attribute: NSLayoutAttribute.Left,
                                             multiplier: 1,
                                             constant: margin)
        commonParrentView.addConstraint(constraint)
        return constraint
    }
    
    func centerYToView(view: UIView, commonParrentView: UIView, margin: CGFloat = 0) -> NSLayoutConstraint {
        let constraint = NSLayoutConstraint (item: self,
                                             attribute: NSLayoutAttribute.CenterY,
                                             relatedBy: NSLayoutRelation.Equal,
                                             toItem: view,
                                             attribute: NSLayoutAttribute.CenterY,
                                             multiplier: 1,
                                             constant: 0) //hardcode
        commonParrentView.addConstraint(constraint)
        return constraint
    }
    
    func centerXToView(view: UIView, commonParrentView: UIView, margin: CGFloat = 0) -> NSLayoutConstraint {
        let constraint = NSLayoutConstraint (item: self,
                                             attribute: NSLayoutAttribute.CenterX,
                                             relatedBy: NSLayoutRelation.Equal,
                                             toItem: view,
                                             attribute: NSLayoutAttribute.CenterX,
                                             multiplier: 1,
                                             constant: margin)
        commonParrentView.addConstraint(constraint)
        return constraint
    }
    
    func addConstraintFillInView(view: UIView, commenParrentView: UIView) ->
        (top: NSLayoutConstraint, bot: NSLayoutConstraint, lead: NSLayoutConstraint, trail: NSLayoutConstraint) {
            
            let top = topMarginToView(view, commonParrentView: commenParrentView)
            let bot = botMarginToView(view, commonParrentView: commenParrentView)
            let lead = leadingMarginToView(view, commonParrentView: commenParrentView)
            let trail = trailingMarginToView(view, commonParrentView: commenParrentView)
            
            return (top, bot, lead, trail)
    }
    
    func copyView() -> UIView {
        return NSKeyedUnarchiver.unarchiveObjectWithData(NSKeyedArchiver.archivedDataWithRootObject(self)) as! UIView
    }
    
    func showTouchAnimation(time: NSTimeInterval) {
        self.transform = CGAffineTransformMakeScale(1.0, 1.0)
        UIView.animateWithDuration(time, delay: 0, options: [.CurveEaseOut, .Autoreverse], animations: { () -> Void in
            self.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.5, 1.5)
        }) { (finish) -> Void in
            self.transform = CGAffineTransformMakeScale(1.0, 1.0)
        }
    }
}
