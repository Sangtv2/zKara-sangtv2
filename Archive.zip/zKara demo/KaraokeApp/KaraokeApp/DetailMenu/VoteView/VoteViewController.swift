//
//  VoteViewController.swift
//
//  Created by SOSO on 7/29/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//


import UIKit
import MBProgressHUD

class VoteViewController: UIViewController, UIWebViewDelegate {

    @IBOutlet var webView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Vote"
        let menuBtn = UIBarButtonItem(image: UIImage(named: "menu"), style: .Done, target: self, action: #selector(KRMainViewController.openSlideMenu))
        
        self.navigationItem.leftBarButtonItem = menuBtn
        self.webView.delegate = self

        let path : String = "http://www.apple.com"
        
        let request = NSURLRequest(URL: NSURL(string: path)!)
        self.webView.loadRequest(request)
  
    }
    func webViewDidStartLoad(webView: UIWebView) {
        MBProgressHUD.showHUDAddedTo(self.webView, animated: true)
    }
    func webViewDidFinishLoad(webView: UIWebView) {
        MBProgressHUD.hideHUDForView(self.webView, animated: true)
    }

    func openSlideMenu() -> Void {
        let appdelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        //appdelegate.controller!.toggle("right")
        
        appdelegate.centerContainer!.toggleDrawerSide(MMDrawerSide.Left, animated: true, completion: nil)
    }
    
}
