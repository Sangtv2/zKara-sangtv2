//
//  QRCodeViewController.swift
//  KaraokeApp
//
//  Created by SOSO on 8/24/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import UIKit
import AVFoundation
import QRCodeReader

class QRCodeViewController: UIViewController,QRCodeReaderViewControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if QRCodeReader.supportsMetadataObjectTypes() {
            let reader = createReader()
            reader.modalPresentationStyle = .FormSheet
            reader.delegate               = self
            
            reader.completionBlock = { (result: QRCodeReaderResult?) in
                if let result = result {
                    print("Completion with result: \(result.value)")
                }
            }
            presentViewController(reader, animated: true, completion: nil)
        }
        else {
            let alert = UIAlertController(title: "Error", message: "Reader not supported by the current device", preferredStyle: .Alert)
            alert.addAction(UIAlertAction(title: "OK", style: .Cancel, handler: nil))
            presentViewController(alert, animated: true, completion: nil)
            
            let appdelegate = UIApplication.sharedApplication().delegate as! AppDelegate
            let mainVC = KRMainViewController(nibName: "KRMainViewController", bundle: nil)
            let mainNavi = UINavigationController(rootViewController : mainVC)
            appdelegate.centerContainer?.centerViewController = mainNavi
            appdelegate.centerContainer?.toggleDrawerSide(MMDrawerSide.Left, animated: true, completion: nil)
            
        }
    }
    func reader(reader: QRCodeReaderViewController, didScanResult result: QRCodeReaderResult) {
        self.dismissViewControllerAnimated(true) {
            
            let code = result.value
            print(code)
            let appdelegate = UIApplication.sharedApplication().delegate as! AppDelegate
            
            let mainVC = KRMainViewController(nibName: "KRMainViewController", bundle: nil)
            mainVC.codeScran = code
            
            NSUserDefaults.standardUserDefaults().setObject(code, forKey: "code")
            
            NSUserDefaults.standardUserDefaults().synchronize()
            
            if let myLoadedString = NSUserDefaults.standardUserDefaults().stringForKey("code") {
                print(myLoadedString)
            }
            
            
            let mainNavi = UINavigationController(rootViewController : mainVC)
            appdelegate.centerContainer?.centerViewController = mainNavi
            appdelegate.centerContainer?.toggleDrawerSide(MMDrawerSide.Left, animated: true, completion: nil)
        }
        
        self.title = "QA Code"
        let menuBtn = UIBarButtonItem(image: UIImage(named: "QR Code"), style: .Done, target: self, action: #selector(KRMainViewController.openSlideMenu))
        self.navigationItem.leftBarButtonItem = menuBtn
    }
    
    func openSlideMenu() -> Void {
        let appdelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        appdelegate.centerContainer!.toggleDrawerSide(MMDrawerSide.Left, animated: true, completion: nil)
    }
    
    
    func readerDidCancel(reader: QRCodeReaderViewController)
    {
        self.dismissViewControllerAnimated(true, completion: nil)
        let appdelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let mainVC = KRMainViewController(nibName: "KRMainViewController", bundle: nil)
        let mainNavi = UINavigationController(rootViewController : mainVC)
        appdelegate.centerContainer?.centerViewController = mainNavi
        appdelegate.centerContainer?.toggleDrawerSide(MMDrawerSide.Left, animated: true, completion: nil)
    }
    
    private func createReader() -> QRCodeReaderViewController {
        let builder = QRCodeViewControllerBuilder { builder in
            builder.reader          = QRCodeReader(metadataObjectTypes: [AVMetadataObjectTypeQRCode])
            builder.showTorchButton = true
        }
        return QRCodeReaderViewController(builder: builder)
    }
}
