//
//  AboutViewController.swift
//
//  Created by SOSO on 7/29/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//


import UIKit

class AboutViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "QA Code"
        let menuBtn = UIBarButtonItem(image: UIImage(named: "Icon-Small"), style: .Done, target: self, action: #selector(KRMainViewController.openSlideMenu))
        
        self.navigationItem.leftBarButtonItem = menuBtn
    }

    func openSlideMenu() -> Void {
        let appdelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        //appdelegate.controller!.toggle("right")
        
        appdelegate.centerContainer!.toggleDrawerSide(MMDrawerSide.Left, animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
