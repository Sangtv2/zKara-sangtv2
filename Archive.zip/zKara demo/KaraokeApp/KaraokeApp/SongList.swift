//
//  SongList.swift
//  KaraokeApp
//
//  Created by SOSO on 9/7/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import Foundation

class SongList: NSObject {
    
    var lisArraySong:NSArray!
    var listTopSong : [SongDetail] = []
    var likeSong    : [SongDetail] = []
    
    class var sharedInstance: SongList {
        struct Static {
            static var onceToken: dispatch_once_t = 0
            static var instance: SongList? = nil
        }
        dispatch_once(&Static.onceToken) {
            Static.instance = SongList()
        }
        return Static.instance!
    }
    
    
    
    func getSearchSongs(dicts: [NSDictionary]) -> [SongDetail] {
        var result : [SongDetail] = []
        for dict in dicts {
            let song = SongDetail(dict: dict)
            result.append(song)
        }
          NSNotificationCenter.defaultCenter().postNotificationName("getSongDetailSuccess", object: result)
        return result
        
    }
}