
//
//  ViewController.swift
//  KaraokeApp
//
//  Created by SOSO on 9/1/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

    import UIKit
    import CoreFoundation
    import SystemConfiguration
    import CFNetwork
    
    var inputStream: NSInputStream?
    var outputStream: NSOutputStream?
    var readStream: CFReadStreamRef?
    var writeStream: CFWriteStreamRef?
    
    var readCommandInput: String?
    
    
    class ViewController: UIViewController, UITextFieldDelegate, NSStreamDelegate {
        
        @IBOutlet weak var commandInput: UITextField!
        @IBOutlet weak var commandOutput: UITextView!
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view, typically from a nib.
            
            UIApplication.sharedApplication().keyWindow?.endEditing(true)
        }
        
        // MARK: NSStreamDelegate
        
        /// Handle an event on a stream.
        func stream(stream: NSStream, handleEvent eventCode: NSStreamEvent) {
            switch eventCode {
            case NSStreamEvent.None:
                print("NSStreamEvent")
            case NSStreamEvent.OpenCompleted:
                print("NSStreamEvent")
            case NSStreamEvent.HasBytesAvailable:
                if stream == inputStream {
                    
                    let bufferSize = 256
                    var buffer = Array<UInt8>(count: bufferSize, repeatedValue: 0)
                    let len = inputStream!.read(&buffer, maxLength: buffer.count)
                    
                    if len > 0 {
                        let output: String = String(bytes: buffer, encoding: NSASCIIStringEncoding)!
                        commandOutput.text = commandOutput.text + "\n" + output
                    }
                }
            case NSStreamEvent.HasSpaceAvailable:
                if stream == outputStream {
                    
                    let message = readCommandInput
                    let data:NSData = message!.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)!
                    outputStream!.write(UnsafePointer(data.bytes), maxLength: data.length)
                    
                }
            case NSStreamEvent.ErrorOccurred:
                NSLog("stream: %@", stream)
            case NSStreamEvent.EndEncountered:
                print("EndEncountered")
            default:
                print("exit")
                break
            }
        }
        
        
        @IBAction func showCommand() {
            readCommandInput = commandInput.text
            
            let ip: CFString = "IP"
            let port = UInt32()
            
            print("connecting...")
            
            var readStream:  Unmanaged<CFReadStream>?
            var writeStream: Unmanaged<CFWriteStream>?
            
            CFStreamCreatePairWithSocketToHost(kCFAllocatorDefault, ip, port, &readStream, &writeStream)
            
            inputStream = readStream!.takeRetainedValue()
            outputStream = writeStream!.takeRetainedValue()
            
            inputStream!.delegate = self
            outputStream!.delegate = self
            
            inputStream!.scheduleInRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
            outputStream!.scheduleInRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
            
            inputStream!.open()
            outputStream!.open()
            
        }
        
        func textFieldShouldReturn(textField: UITextField) -> Bool {
            
            self.view.endEditing(false)
            
            return true
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
        }
        
}
