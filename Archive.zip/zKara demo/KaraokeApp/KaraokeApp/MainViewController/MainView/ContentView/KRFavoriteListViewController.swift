//
//  KRLikeSongViewController.swift
//  KaraokeApp
//
//  Created by SOSO on 8/11/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import UIKit
import PopupDialog
import AVFoundation
import MBProgressHUD

protocol  getLikeDelegate
{
    func selectSongFromClient(title: String!, id: String!,server_id: String!,device_id:String!)
}

class KRFavoriteListViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var main = KRMainViewController()
    var listFavorite = NSArray()
    
    //    var listLikeSong = [SongDetail]()
    var delegateLike : getLikeDelegate? = nil
    @IBOutlet weak var tableFavoriteList: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchData()
        self.tableFavoriteList.delegate = self
        self.tableFavoriteList.dataSource = self
        self.tableFavoriteList.registerNib(UINib.init(nibName: "CustonTableViewCell", bundle: nil),
                                           forCellReuseIdentifier: "CustonTableViewCell")
        
        if SongList.sharedInstance.lisArraySong != nil{
            SongList.sharedInstance.lisArraySong = [listFavorite]
        }
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
        tableFavoriteList.reloadData()
    }
    func fetchData()
    {
        let loadingNotification = MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        loadingNotification.mode = MBProgressHUDMode.Indeterminate
        loadingNotification.color = UIColor.whiteColor()
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.listFavorite.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableFavoriteList.dequeueReusableCellWithIdentifier("CustomTableViewCell", forIndexPath: indexPath) as! CustomTableViewCell
        
        let detailStrong:SongDetail = self.listFavorite[indexPath.row] as! SongDetail
        
        cell.lblTitle.text = detailStrong.title
        cell.imgView?.sd_setImageWithURL(NSURL.init(string: (detailStrong.thumbnail!.defaults?.url)!), completed: nil)
        
        
        
        
        return cell
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return height
    }
    
    /** DidSelectRowAtIndexPath */
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let selectedCell = tableView.cellForRowAtIndexPath(indexPath)!
        
        selectedCell.backgroundColor = UIColor.whiteColor()
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        if let navController = self.navigationController
        {
            navController.popViewControllerAnimated(true)
        }
        let popup = PopupDialog(title:MenuLike, message:"")
        
        let btnSelect = DefaultButton(title: addplaySong)
        {
            let selectedCell = tableView.cellForRowAtIndexPath(indexPath)!
            
            selectedCell.backgroundColor = UIColor.whiteColor()
            tableView.deselectRowAtIndexPath(indexPath, animated: true)
            
            let detailStrong:SongDetail = self.listFavorite[indexPath.row] as! SongDetail
            
            self.delegateLike?.selectSongFromClient("\(detailStrong.title)",
                                                    id: "\(detailStrong.videoID.videoId)",
                                                    server_id:server,device_id:device)
        }
        let btnAdd = DefaultButton(title: addTop)
        {
            let detailStrong:SongDetail = self.listFavorite[indexPath.row] as! SongDetail
            
            self.main.selectTopVideoFromClient("\(detailStrong.title)",id: "\(detailStrong.videoID.videoId)")
            
        }
        let btnDelete = DefaultButton(title: Delete)
        {
            let indexRow = self.listFavorite[indexPath.row]
            self.main.removeFromClient("\(indexRow)",pos: indexPath.row)
            
        }
        
        let btnPlayNow = DefaultButton(title: playnow)
        {
            let detailStrong:SongDetail = self.listFavorite[indexPath.row] as! SongDetail
            self.main.playNowFromClient("\(detailStrong.title)",id: "\(detailStrong.videoID.videoId)")
        }
        let btnCancel = DefaultButton(title: Cancel, action: nil)
        btnCancel.backgroundColor = UIColor.lightGrayColor()
        btnCancel.titleFont = UIFont(name: Futura, size: 18)!
        
        popup.addButtons([btnSelect ,btnAdd, btnPlayNow,btnDelete,btnCancel])
        self.presentViewController(popup, animated: true, completion: nil)
        self.tableFavoriteList.reloadData()
    }
    
    /** ======Stream audio microphone via bluetooth====== */
}

