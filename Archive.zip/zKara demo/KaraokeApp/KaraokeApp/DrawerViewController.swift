//
//  DrawerViewController.swift
//  KaraokeApp
//
//  Created by SOSO on 9/10/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import UIKit

class DrawerViewController: UIViewController {

    @IBOutlet weak var coverButton: UIButton!
    
    var isOpened: Bool = false {
        didSet {
            if isOpened {
                showMenu()
            } else {
                hideMenu(NSObject())

            }
        }
    }
    @IBOutlet weak var menuContainer: UIView!
    
    @IBOutlet weak var leftConstraintMenu: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.leftConstraintMenu.constant = -self.menuContainer.bounds.width
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(toggleMenu), name: "toggleMenu", object: nil)
        coverButton.hidden = true
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    deinit {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    func toggleMenu(notification: NSNotification) {
        isOpened = !isOpened
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func showMenu() {
        UIView.animateWithDuration(0.35) {
            
        }
        
        UIView.animateWithDuration(0.35, animations: { 
            self.leftConstraintMenu.constant = 0
            self.view.layoutIfNeeded()
            }) { (success) in
                self.coverButton.hidden = false
        }
    }
    
    @IBAction func hideMenu(sender: AnyObject) {
        UIView.animateWithDuration(0.35, animations: {
            self.leftConstraintMenu.constant = -self.menuContainer.bounds.width
            self.view.layoutIfNeeded()
        }) { (success) in
            if success {
                self.coverButton.hidden = true
            }
        }
    }
}
