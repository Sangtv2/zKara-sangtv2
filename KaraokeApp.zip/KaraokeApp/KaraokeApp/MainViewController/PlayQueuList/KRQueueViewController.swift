//
//  KRQueueViewController.swift
//  KaraokeApp
//
//  Created by SOSO on 8/2/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import UIKit
import PopupDialog
import youtube_parser
import MediaPlayer

class KRQueueViewController: UIViewController, UITableViewDataSource,UITableViewDelegate{
    
    var jsonArrayID = NSMutableArray()
    
    @IBOutlet weak var imageUpDown: UIImageView!
    @IBOutlet weak var playPause: UIButton!
    @IBOutlet weak var btnPlay: UIButton!
    @IBOutlet weak var countQueue: UILabel!
    @IBOutlet weak var titleSongPlay: UILabel!
    @IBOutlet weak var imageSongPlay: UIImageView!
    @IBOutlet weak var tableQueue: UITableView!
    @IBOutlet weak var heighConstrant : NSLayoutConstraint!
    
    /** Action UIButton */
    
    @IBAction func btnQlityVideo(sender: AnyObject) {
        let main = KRMainViewController()
        main.chaneQualityFromClient()
    }
    @IBAction func pause(sender: AnyObject)
    {
        let main = KRMainViewController()
        self.btnPlay.selected = !self.btnPlay.selected
        main.playPlause()
    }
    @IBAction func btnPlayPause(sender: UIButton) {
        let main = KRMainViewController()
        self.playPause.selected = !self.playPause.selected
        main.playPlause()
    }
    @IBAction func next(sender: AnyObject)
    {
        let main = KRMainViewController()
        main.nextVideoFromClient()
    }
    
    /** QUEUE TITLE */
    func titleSong(titleSongs : String)
    {
        dispatch_async(dispatch_get_main_queue()){
            self.titleSongPlay.text? = titleSongs
            self.playPause.hidden = false
        }
    }
    
    /** QUEUE ID */
    func upateCurrentImage(idSongs : String)
    {
        dispatch_async(dispatch_get_main_queue()){
            self.imageSongPlay.hidden = false
            let thumb = thumbImage + idSongs + jpg
            self.imageSongPlay.sd_setImageWithURL(NSURL.init(string: thumb),completed: nil)
        }
    }
    func updateCurrentSongsList(currentStatus : Int)
    {
        dispatch_async(dispatch_get_main_queue()){
            print("Current \(currentStatus)")
            
        }
    }
    
    /** JSON STRING */
    func playQueueList(queueList : String?)
    {
        dispatch_async(dispatch_get_main_queue(),{
            let play_queue = queueList
            let StringID = NSCharacterSet(charactersInString: ",")
            let words = play_queue!.componentsSeparatedByCharactersInSet(StringID)
            
            self.jsonArrayID.removeAllObjects()
            
            if queueList == ""
            {
                let count =  self.jsonArrayID.count
                self.countQueue.text = "\(titleCount)\(count)"
            }
            else
            {
                for item in words
                {
                    let cutString = String(item)
                    self.jsonArrayID.addObject(cutString)
                    let main = KRMainViewController()
                    main.updateCurrentSongPlayingFromClient()
                    let count =  self.jsonArrayID.count
                    self.countQueue.text = "\(titleCount)\(count)"
                }
                self.tableQueue.reloadData()
            }
        })
        
    }
    
    /** ViewDidLoad */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        
        self.playPause.hidden = true
        self.tableQueue.registerNib(UINib.init(nibName: "CustonTableViewCell", bundle: nil),forCellReuseIdentifier: "CustonTableViewCell")
        
        self.tableQueue.delegate = self
        self.tableQueue.dataSource = self
        
        self.tableQueue.tableFooterView = UIView()
        self.tableQueue.rowHeight = 60
        
        self.imageSongPlay.hidden = true
    }
    
    /** NumberOfRowsInSection */
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.jsonArrayID.count
    }
    
    /** CellForRowAtIndexPath */
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell : CustonTableViewCell = tableView.dequeueReusableCellWithIdentifier("CustonTableViewCell", forIndexPath: indexPath) as! CustonTableViewCell
        let main = KRMainViewController()
        main.updateCurrentSongPlayingFromClient()
        let id = jsonArrayID[indexPath.row] as! String
        let URL = urlTitle + id
        let thumb = thumbImage + id + jpg
        let url = NSURL(string: URL)
        
        Youtube.h264videosWithYoutubeURL(url!) { (videoInfo, error) in
            
            if  let title = videoInfo?[titles] as? String
            {
                cell.lblTitle.text = title
                cell.imgView?.sd_setImageWithURL(NSURL.init(string: thumb, relativeToURL: nil))
            }
        }
        return cell
    }
    
    /** HeightForRowAtIndexPath */
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return height
    }
    
    /** DidSelectRowAtIndexPath */
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let selectedCell = tableView.cellForRowAtIndexPath(indexPath)!
        
        selectedCell.backgroundColor = UIColor.whiteColor()
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        tableQueue.reloadRowsAtIndexPaths([indexPath], withRowAnimation: .Automatic)
        
        
        let popup = PopupDialog(title: MenuQueue, message: "")
        let btnPlayNow = DefaultButton(title: playnow)
        {
            for id in self.jsonArrayID
            {
                let indexRow = self.jsonArrayID[indexPath.row]
                
                let URL = urlTitle + (id as! String)
                let url = NSURL(string: URL)
                Youtube.h264videosWithYoutubeURL(url!) { (videoInfo, error) in
                    if  let titles = videoInfo?[titles] as? String {
                        let main = KRMainViewController()
                        main.playNowFromClient("\(titles)",id: "\(indexRow)")
                    }
                }
            }
        }
        let btnTop = DefaultButton(title: addTop)
        {
            let indexRow = self.jsonArrayID[indexPath.row]
            let main = KRMainViewController()
            main.chanePriorityPlayQueue("\(indexRow)")
        }
        
        let btnYT = DefaultButton(title: like)
        {
            let dataList = self.jsonArrayID[indexPath.row]
            NSNotificationCenter .defaultCenter() .postNotificationName(likeVC, object: dataList)
        }
        
        let btnDelete = DefaultButton(title:Delete)
        {
            let indexRow = self.jsonArrayID[indexPath.row]
            let main = KRMainViewController()
            main.removeFromClient("\(indexRow)",pos: indexPath.row)
            
        }
        let btnCancel = DefaultButton(title: Cancel, action: nil)
        btnCancel.backgroundColor = UIColor.greenColor()
        btnCancel.titleFont = UIFont(name: Futura, size: 18)!
        
        popup.addButtons([btnPlayNow,btnTop,btnYT,btnDelete,btnCancel ])
        
        self.presentViewController(popup, animated: true, completion: nil)
        
    }
}