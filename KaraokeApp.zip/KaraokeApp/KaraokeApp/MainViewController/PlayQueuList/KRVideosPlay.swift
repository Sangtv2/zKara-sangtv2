//
//  KRVideosPlay.swift
//  KaraokeApp
//
//  Created by SOSO on 9/12/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import Foundation
import AVFoundation
import MediaPlayer


let LGVideosPlayerOnTrackChangedNotification = "LGVideosPlayerOnTrackChangedNotification"
let LGVideosPlayerOnPlaybackStateChangedNotification = "LGVideosPlayerOnPlaybackStateChangedNotification"

public struct KRPlayBackItem {
    let fileURL: NSURL
    let trackName: String
    let albumName: String
    let artistName: String
    let albumImageName: String
}

extension KRPlayBackItem : Equatable {}
public func ==(lhs: KRPlayBackItem, rhs: KRPlayBackItem) -> Bool {
    return lhs.fileURL.absoluteString == rhs.fileURL.absoluteString
}

public class KRVideoPlay: NSObject , AVAudioPlayerDelegate{
    //MARK: - Vars
    
    var videosPlayr : AVAudioPlayer?
    public var playbackItems: [KRPlayBackItem]?
    public var currentPlaybackItem: KRPlayBackItem?
    public var nextPlaybackItem: KRPlayBackItem? {
        guard let playbackItems = self.playbackItems, currentPlaybackItem = self.currentPlaybackItem else { return nil }
        
        let nextItemIndex = playbackItems.indexOf(currentPlaybackItem)! + 1
        if nextItemIndex >= playbackItems.count { return nil }
        
        return playbackItems[nextItemIndex]
    }
    public var previousPlaybackItem: KRPlayBackItem? {
        guard let playbackItems = self.playbackItems, currentPlaybackItem = self.currentPlaybackItem else { return nil }
        
        let previousItemIndex = playbackItems.indexOf(currentPlaybackItem)! - 1
        if previousItemIndex < 0 { return nil }
        
        return playbackItems[previousItemIndex]
    }
    var nowPlayingInfo: [String : AnyObject]?
    
    public var currentTime: NSTimeInterval? {
        return videosPlayr?.currentTime
    }
    
    public var duration: NSTimeInterval? {
        return self.videosPlayr?.duration
    }
    
    public var isPlaying: Bool {
        return self.videosPlayr?.playing ?? false
    }
    
    //MARK: - Dependencies
    
    let videoSession: AVAudioSession
    let commandCenter: MPRemoteCommandCenter
    let nowPlayingInfoCenter: MPNowPlayingInfoCenter
    let notificationCenter: NSNotificationCenter
    
    //MARK: - Init
    
    typealias LGAudioPlayerDependencies = (audioSession: AVAudioSession, commandCenter: MPRemoteCommandCenter, nowPlayingInfoCenter: MPNowPlayingInfoCenter, notificationCenter: NSNotificationCenter)
    
    init(dependencies: LGAudioPlayerDependencies) {
        self.videoSession = dependencies.audioSession
        self.commandCenter = dependencies.commandCenter
        self.nowPlayingInfoCenter = dependencies.nowPlayingInfoCenter
        self.notificationCenter = dependencies.notificationCenter
        
        super.init()
        
        try! self.videoSession.setCategory(AVAudioSessionCategoryPlayback)
        try! self.videoSession.setActive(true)
        
        self.configureCommandCenter()
    }
    //MARK: - Playback Commands
    
    public func playItems(playbackItems: [KRPlayBackItem], firstItem: KRPlayBackItem? = nil) {
        self.playbackItems = playbackItems
        
        if playbackItems.count == 0 {
            self.endPlayback()
            return
        }
        
        let playbackItem = firstItem ?? self.playbackItems!.first!
        
        self.playItem(playbackItem)
    }
    func playItem(playbackItem: KRPlayBackItem) {
        guard let videoPlayer = try? AVAudioPlayer(contentsOfURL: playbackItem.fileURL) else {
            self.endPlayback()
            return
        }
        
        videoPlayer.delegate = self
        videoPlayer.prepareToPlay()
        videoPlayer.play()
        self.videosPlayr = videoPlayer
        
        self.currentPlaybackItem = playbackItem
        
        self.updateNowPlayingInfoForCurrentPlaybackItem()
        self.updateCommandCenter()
        
        self.notifyOnTrackChanged()
    }
    public func togglePlayPause() {
        if self.isPlaying {
            self.pause()
        }
        else {
            self.play()
        }
    }
    
    public func play() {
        self.videosPlayr?.play()
        self.updateNowPlayingInfoElapsedTime()
        self.notifyOnPlaybackStateChanged()
    }
    
    public func pause() {
        self.videosPlayr?.pause()
        self.updateNowPlayingInfoElapsedTime()
        self.notifyOnPlaybackStateChanged()
    }
    
    public func nextTrack() {
        guard let nextPlaybackItem = self.nextPlaybackItem else { return }
        self.playItem(nextPlaybackItem)
        self.updateCommandCenter()
    }
    
    public func previousTrack() {
        guard let previousPlaybackItem = self.previousPlaybackItem else { return }
        self.playItem(previousPlaybackItem)
        self.updateCommandCenter()
    }
    
    public func seekTo(timeInterval: NSTimeInterval) {
        self.videosPlayr?.currentTime = timeInterval
        self.updateNowPlayingInfoElapsedTime()
    }
    //MARK: - Command Center
    
    func updateCommandCenter() {
        guard let playbackItems = self.playbackItems, currentPlaybackItem = self.currentPlaybackItem else { return }
        
        self.commandCenter.previousTrackCommand.enabled = currentPlaybackItem != playbackItems.first!
        self.commandCenter.nextTrackCommand.enabled = currentPlaybackItem != playbackItems.last!
    }
    
    func configureCommandCenter() {
        self.commandCenter.playCommand.addTargetWithHandler { [weak self] event -> MPRemoteCommandHandlerStatus in
            guard let sself = self else { return .CommandFailed }
            sself.play()
            return .Success
        }
        self.commandCenter.pauseCommand.addTargetWithHandler { [weak self] event -> MPRemoteCommandHandlerStatus in
            guard let sself = self else { return .CommandFailed }
            sself.pause()
            return .Success
        }
        
        self.commandCenter.nextTrackCommand.addTargetWithHandler { [weak self] event -> MPRemoteCommandHandlerStatus in
            guard let sself = self else { return .CommandFailed }
            sself.nextTrack()
            return .Success
        }
        
        self.commandCenter.previousTrackCommand.addTargetWithHandler { [weak self] event -> MPRemoteCommandHandlerStatus in
            guard let sself = self else { return .CommandFailed }
            sself.previousTrack()
            return .Success
        }
        
    }
    //MARK: - Now Playing Info
    
    func updateNowPlayingInfoForCurrentPlaybackItem() {
        guard let audioPlayer = self.videosPlayr, currentPlaybackItem = self.currentPlaybackItem else {
            self.configureNowPlayingInfo(nil)
            return
        }
        
        var nowPlayingInfo = [MPMediaItemPropertyTitle: currentPlaybackItem.trackName,
                              MPMediaItemPropertyAlbumTitle: currentPlaybackItem.albumName,
                              MPMediaItemPropertyArtist: currentPlaybackItem.artistName,
                              MPMediaItemPropertyPlaybackDuration: audioPlayer.duration,
                              MPNowPlayingInfoPropertyPlaybackRate: NSNumber(float: 1.0)]
        
        if let image = UIImage(named: currentPlaybackItem.albumImageName) {
            nowPlayingInfo[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(image: image)
        }
        
        self.configureNowPlayingInfo(nowPlayingInfo)
        
        self.updateNowPlayingInfoElapsedTime()
    }
    func updateNowPlayingInfoElapsedTime() {
        guard var nowPlayingInfo = self.nowPlayingInfo, let audioPlayer = self.videosPlayr else { return }
        
        nowPlayingInfo[MPNowPlayingInfoPropertyElapsedPlaybackTime] = NSNumber(double: audioPlayer.currentTime);
        
        self.configureNowPlayingInfo(nowPlayingInfo)
    }
    
    func configureNowPlayingInfo(nowPlayingInfo: [String: AnyObject]?) {
        self.nowPlayingInfoCenter.nowPlayingInfo = nowPlayingInfo
        self.nowPlayingInfo = nowPlayingInfo
    }
    
    //MARK: - AVVideoPlayerDelegate
    public func audioPlayerDidFinishPlaying(player: AVAudioPlayer, successfully flag: Bool) {
        if self.nextPlaybackItem == nil {
            self.endPlayback()
        }
        else {
            self.nextTrack()
        }
    }
    
    func endPlayback() {
        self.currentPlaybackItem = nil
        self.videosPlayr = nil
        
        self.updateNowPlayingInfoForCurrentPlaybackItem()
        self.notifyOnTrackChanged()
    }
    
    public func audioPlayerBeginInterruption(player: AVAudioPlayer) {
        self.notifyOnPlaybackStateChanged()
    }
    
    public func audioPlayerEndInterruption(player: AVAudioPlayer, withOptions flags: Int) {
        if AVAudioSessionInterruptionOptions(rawValue: UInt(flags)) == .ShouldResume {
            self.play()
        }
    }
    //MARK: - Convenience
    
    func notifyOnPlaybackStateChanged() {
        self.notificationCenter.postNotificationName(LGVideosPlayerOnPlaybackStateChangedNotification, object: self)
    }
    
    func notifyOnTrackChanged() {
        self.notificationCenter.postNotificationName(LGVideosPlayerOnTrackChangedNotification, object: self)
    }
    
    //MARK: -

}


