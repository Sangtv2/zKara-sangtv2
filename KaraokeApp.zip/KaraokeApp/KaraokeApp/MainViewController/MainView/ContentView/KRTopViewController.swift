//
//  KRTopViewController.swift
//  KaraokeApp
//
//  Created by SOSO on 7/29/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import UIKit
import PopupDialog
import Alamofire
import MBProgressHUD

protocol  getDelegate
{
    func selectSongFromClient(title: String!, id: String!,server_id: String!,device_id:String!)
}

class KRTopViewController: UIViewController,UITableViewDataSource,UITableViewDelegate ,UIPopoverPresentationControllerDelegate{
    var main = KRMainViewController()
    var listTopSong : [SongDetail] = []
    
    var delegateTop : getDelegate? = nil
    
    @IBOutlet weak var tableViewTop: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchData()
        self.tableViewTop.registerNib(UINib.init(nibName: "CustonTableViewCell", bundle: nil),
                                      forCellReuseIdentifier: "CustonTableViewCell")
        tableViewTop.delegate = self
        tableViewTop.dataSource = self
        
    }
    
    func fetchData()
    {
        let loadingNotification = MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        loadingNotification.mode = MBProgressHUDMode.Indeterminate
        loadingNotification.color = UIColor.lightGrayColor()
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0))
        {
            dispatch_async(dispatch_get_main_queue())
            {
                DataService().getVideoHD(urlTop, handle: self.handleReturnValue)
            }
        }
    }
    
    func handleReturnValue(dict: [NSDictionary]) {
        
        for dict in dict {
            let song = SongDetail(dict: dict)
            listTopSong.append(song)
        }
        tableViewTop.reloadData()
        MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return listTopSong.count
    }
    
    /* CellForRowAtIndexPath*/
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell : CustonTableViewCell = tableView.dequeueReusableCellWithIdentifier("CustonTableViewCell", forIndexPath: indexPath) as! CustonTableViewCell
        
        let detailStrong:SongDetail = listTopSong[indexPath.row]
        
        cell.lblTitle.text = detailStrong.title
        cell.imgView?.sd_setImageWithURL(NSURL.init(string: (detailStrong.thumbnail.defaults?.url)!), completed: nil)
        
        return cell
    }
    
    /*Did Select Row At IndexPath*/
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let popup = PopupDialog(title:MenuTop, message:"")
        
        let btnSelect = DefaultButton(title:addplaySong )
        {
            
            let detailStrong:SongDetail = self.listTopSong[indexPath.row]
            
            self.delegateTop?.selectSongFromClient("\(detailStrong.title)",
                                                   id: "\(detailStrong.videoID.videoId)",
                                                   server_id: server,device_id:device)
        }
        let btnAdd = DefaultButton(title: addTop)
        {
            let detailStrong:SongDetail = self.listTopSong[indexPath.row]
            
            self.main.selectTopVideoFromClient("\(detailStrong.title)",id: "\(detailStrong.videoID.videoId)")
            
        }
        let btnPlayNow = DefaultButton(title: playnow)
        {
            let detailStrong:SongDetail = self.listTopSong[indexPath.row]
            self.main.playNowFromClient("\(detailStrong.title)",id: "\(detailStrong.videoID.videoId)")
        }
        let btnYT = DefaultButton(title: like)
        {
            let dataList:SongDetail = self.listTopSong[indexPath.row]
            NSNotificationCenter .defaultCenter() .postNotificationName(likeVC, object: dataList)
        }
        let btnCancel = DefaultButton(title: Cancel, action: nil)
        btnCancel.backgroundColor = UIColor.lightGrayColor()
        btnCancel.titleFont = UIFont(name: Futura, size: 18)!
        
        popup.addButtons([btnSelect ,btnAdd, btnPlayNow,btnYT,btnCancel ])
        self.presentViewController(popup, animated: true, completion: nil)
        self.tableViewTop.reloadData()
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return height
    }
    
}