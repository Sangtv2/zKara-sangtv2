//
//  KRSearchViewController.swift
//  KaraokeApp
//
//  Created by SOSO on 7/30/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import UIKit
import PopupDialog
import SDWebImage
import MBProgressHUD

protocol  getDataDelegate
{
    func selectSongFromClient(title: String!, id: String!,server_id: String!,device_id:String!)
}

class KRSearchViewController: UIViewController ,UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate  {
    var main = KRMainViewController()
    var listTopSong : [SongDetail] = []
    
    // IBOutlet
    @IBOutlet var tableView: UITableView!
    @IBOutlet var searchBar: UISearchBar!
    
    // var -- let
    var delegateCustom : getDataDelegate? = nil
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.searchBar.delegate = self
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.searchBar.placeholder = keySearch
        self.searchBar.sizeToFit()
        self.searchBar.showsCancelButton = false
        self.definesPresentationContext = true
        self.tableView.registerNib(UINib.init(nibName: "CustonTableViewCell", bundle: nil),
                                   forCellReuseIdentifier: "CustonTableViewCell")
    }
    
    func fetchData()
    {
        let loadingNotification = MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        loadingNotification.mode = MBProgressHUDMode.Indeterminate
        loadingNotification.color = UIColor.lightGrayColor()
        
    }
    
    /** Search bar button click - parameter searchBar: UISearchBar */
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        
        let karaoke : String = " intitle:karaoke"
        var key : String = searchBar.text! + karaoke
        key = key.stringByReplacingOccurrencesOfString(" ", withString: "+",
                                                       options: NSStringCompareOptions.LiteralSearch, range: nil)
        
        let urlSearch = "https://www.googleapis.com/youtube/v3/search?part=snippet&order=viewCount&maxResults=50&type=video&q=\(key)&key=\(apiKey)"
        
        searchBar.resignFirstResponder()
        
        self.fetchData()
        DataService().getVideoHD(urlSearch, handle: handleReturnValue)
        
        tableView.reloadData()
        
    }
    
    
    func handleReturnValue(dict: [NSDictionary]) {
        
        for dict in dict {
            let song = SongDetail(dict: dict)
            listTopSong.append(song)
        }
        tableView.reloadData()
        MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
        
    }
    
    /* Number of Row in Section */
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listTopSong.count
        
    }
    
    /* Cell for row at indexPath */
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell : CustonTableViewCell = tableView.dequeueReusableCellWithIdentifier("CustonTableViewCell", forIndexPath: indexPath) as! CustonTableViewCell
        
        if (listTopSong.count - 1 >= indexPath.row)
        {
            let detailStrong:SongDetail = listTopSong[indexPath.row]
            cell.lblTitle.text = detailStrong.title
            cell.imgView?.sd_setImageWithURL(NSURL.init(string: (detailStrong.thumbnail.defaults?.url)!), completed: nil)
        }
        return cell
    }
    /* Height For Row At IndexPath */
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return height
    }
    
    /* Did Select Row At IndexPath */
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
        
    {
        
        let selectedCell = tableView.cellForRowAtIndexPath(indexPath)!
        
        selectedCell.backgroundColor = UIColor.whiteColor()
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let popup = PopupDialog(title: MENU, message:"")
        
        let btnSelect = DefaultButton(title: addplaySong)
        {
            
            let selectedCell = tableView.cellForRowAtIndexPath(indexPath)!
            
            selectedCell.backgroundColor = UIColor.whiteColor()
            tableView.deselectRowAtIndexPath(indexPath, animated: true)
            
            let detailStrong:SongDetail = self.listTopSong[indexPath.row]
            self.delegateCustom?.selectSongFromClient("\(detailStrong.title)",
                                                      id: "\(detailStrong.videoID.videoId)",
                                                      server_id:server ,device_id:device)
        }
        let btnAdd = DefaultButton(title: addTop)
        {
            let detailStrong = self.listTopSong[indexPath.row]
            self.main.selectTopVideoFromClient("\(detailStrong.title)",id: "\(detailStrong.videoID.videoId)")
            
        }
        
        let btnPlayNow = DefaultButton(title: playnow)
        {
            let detailStrong:SongDetail = self.listTopSong[indexPath.row]
            self.main.playNowFromClient("\(detailStrong.title)",id: "\(detailStrong.videoID.videoId)")
        }
        let btnYT = DefaultButton(title: like)
        {
            let dataList = self.listTopSong[indexPath.row]
            NSNotificationCenter .defaultCenter() .postNotificationName(likeVC, object: dataList)
        }
        
        let btnCancel = DefaultButton(title: Cancel, action: nil)
        btnCancel.backgroundColor = UIColor.lightGrayColor()
        btnCancel.titleFont = UIFont(name: Futura, size: 18)
        
        popup.addButtons([btnSelect ,btnAdd, btnPlayNow,btnYT,btnCancel ])
        self.presentViewController(popup, animated: true, completion: nil)
        
        self.tableView.reloadData()
    }
    
//        func searchBar(searchBar: UISearchBar,textDidChange searchText: String)
//        {
//            self.searchBarSearchButtonClicked(searchBar)
//            searchBar.becomeFirstResponder()
//        }
 
}

