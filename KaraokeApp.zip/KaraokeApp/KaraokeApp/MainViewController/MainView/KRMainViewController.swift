
//
//  KRMainViewController.swift
//  KaraokeApp
//
//  Created by SOSO on 7/29/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import UIKit


class KRMainViewController: UIViewController ,getDataDelegate ,getDelegate, getLikeDelegate,UICollectionViewDelegateFlowLayout{
    
    
    
    // Run time
    var runtime = true
    
    // Layout Constraint
    var topMargin: NSLayoutConstraint!
    var botMargin: NSLayoutConstraint!
    
    // Array
    var stringList = NSMutableArray()
    
    /* View Did Load */
    var queue = KRQueueViewController(nibName:"KRQueueViewController",bundle: nil)
    override func viewDidLoad()
    {
        super.viewDidLoad()
        setupChildView()
        getDeviceId()
        UdpBroadcastserver()
        KRNavigationViewController()
        serverId(server)
        self.updatePlayQueueFromClient()
        
        // Read data file
        let stdinput = NSFileHandle.fileHandleWithStandardInput()
        stdinput.readDataToEndOfFile()
        
        // UIPan Gesture Recognizer
        let pan = UIPanGestureRecognizer(target: self, action: #selector(KRMainViewController.handlePan(_:)))
        queue.view.addGestureRecognizer(pan)
        queue.view.userInteractionEnabled = true
        
        //UITap Gesture Recognizer
        let tap = UITapGestureRecognizer(target: self, action: #selector(KRMainViewController.handlePan(_:)))
        queue.view.addGestureRecognizer(tap)
        queue.view.userInteractionEnabled = true
        
        // Notification Center
        NSNotificationCenter.defaultCenter().addObserver(self, selector:#selector(reviceListSongData(_:)) , name: "likeVC", object: nil)
        
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        KRNavigationViewController()
        
    }
    
    /** Open Slide Menu Left*/
    func openSlideMenu() -> Void
    {
        let appdelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        appdelegate.centerContainer!.toggleDrawerSide(MMDrawerSide.Left,
                                                      animated: true, completion: nil)
    }
    /** Button Open Menu */
    func createButtonMenu()
    {
        
        let button:UIButton = UIButton(frame: CGRectMake(8.2 , 37.5,  25 , 25))
        button.backgroundColor = UIColor.clearColor()
        button.imageView?.image = UIImage(named:menu)!.imageWithRenderingMode(UIImageRenderingMode.AlwaysTemplate)
        button.tintColor = UIColor.whiteColor()
        button.addTarget(self, action:#selector(KRMainViewController.OpenMenu), forControlEvents: .TouchUpInside)
        self.view.addSubview(button)
    }
    
    /** Button Open Menu */
    func OpenMenu()
    {
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            
            self.openSlideMenu()
        }
    }
    
    /** Handle Pan Gesture Recognizer */
    func handlePan(sender:UIPanGestureRecognizer)
    {
        let heightView : CGFloat = view.frame.size.height
        if (sender.state == UIGestureRecognizerState.Ended)
        {
            if self.topMargin.constant == 20
            {
                self.updatePlayQueueFromClient()
                self.queue.imageUpDown.image = UIImage(named:ic_arrow_right)
                self.queue.playPause.hidden = false
                topMargin.constant = heightView - 60
                UIView.animateWithDuration(0.5)
                {
                    self.view.layoutIfNeeded()
                }
            }
            else {
                self.updatePlayQueueFromClient()
                self.queue.imageUpDown.image = UIImage(named:ic_arrow_left)
                self.queue.playPause.hidden = true
                self.topMargin.constant = 20
                UIView.animateWithDuration(0.5)
                {
                    self.view.layoutIfNeeded()
                }
            }
        }
    }
    
    /* Gesture Recognizer */
    func gestureRecognizer(gestureRecognizer: UIGestureRecognizer,
                           shouldRecognizeSimultaneouslyWithGestureRecognizer otherGestureRecognizer: UIGestureRecognizer) -> Bool
    {
        return true
    }
    
    /* setup ChildView */
    func setupChildView(){
        
        if !view.subviews.contains(queue.view)
        {
            let viewQueue = queue.view
            viewQueue.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(viewQueue)
            
            topMargin = NSLayoutConstraint(item: viewQueue, attribute: .Top, relatedBy: .Equal, toItem: view, attribute: .TopMargin, multiplier: 1, constant: 0)
            
            viewQueue.leadingMarginToView(view, commonParrentView: view)
            viewQueue.trailingMarginToView(view, commonParrentView: view)
            
            botMargin = NSLayoutConstraint(item: viewQueue, attribute: .Bottom, relatedBy: NSLayoutRelation.GreaterThanOrEqual, toItem: view, attribute: .Bottom, multiplier: 1, constant: 0)
            
            view.addConstraint(topMargin)
            view.addConstraint(botMargin)
        }
    }
    /* ViewDid Layout Subviews */
    override func viewDidLayoutSubviews()
    {
        super.viewDidLayoutSubviews()
        createButtonMenu()
        
        if runtime == true
        {
            runtime = false
            let height : CGFloat = view.frame.size.height
            topMargin.constant = height - 60
        }
    }
    
    /*  Navigation View Controller */
    func KRNavigationViewController()
    {
        self.navigationController?.navigationBarHidden = true
        
        let items = [UIImage(named: "menu")!,"TÌM KIẾM","TOP","YÊU THÍCH"]
        let carbonTabSwipeNavigation = CarbonTabSwipeNavigation(items: items, delegate: self)
        carbonTabSwipeNavigation.insertIntoRootViewController(self)
        carbonTabSwipeNavigation.setTabBarHeight(60)
        carbonTabSwipeNavigation.setTabExtraWidth(UIScreen.mainScreen().bounds.size.width/4)
        carbonTabSwipeNavigation.setIndicatorHeight(2.5)
        carbonTabSwipeNavigation.setIndicatorColor(UIColor.cyanColor())
        carbonTabSwipeNavigation.setIndicatorBackgroundColor(UIColor.blueColor())
        carbonTabSwipeNavigation.setNormalColor(UIColor.whiteColor(), font: UIFont.boldSystemFontOfSize(15))
        carbonTabSwipeNavigation.setSelectedColor(UIColor.cyanColor(), font: UIFont.boldSystemFontOfSize(22))
        view.bringSubviewToFront(queue.view)
        
    }
    
    
    /** CarbonTabSwipeNavigation View COntroller At Index*/
    func carbonTabSwipeNavigation(carbonTabSwipeNavigation: CarbonTabSwipeNavigation, viewControllerAtIndex index: UInt) -> UIViewController
    {
        let MenuVC = ViewController(nibName: "ViewController", bundle:nil)
        let SearchVideo = KRSearchViewController(nibName: "KRSearchViewController", bundle: nil)
        let TopVideo = KRTopViewController(nibName: "KRTopViewController", bundle: nil)
        let FavoriteListSong = KRFavoriteListViewController(nibName: "KRFavoriteListViewController", bundle: nil)
        
        switch index {
        case 0:
            return MenuVC
        case 1:
            SearchVideo.delegateCustom = self
            return SearchVideo
        case 2:
            TopVideo.delegateTop = self
            return TopVideo
        default:
            FavoriteListSong.delegateLike = self
            FavoriteListSong.listFavorite = self.stringList
            
            return FavoriteListSong
        }
    }
    
    /** Did Move At Index*/
    func carbonTabSwipeNavigation(carbonTabSwipeNavigation: CarbonTabSwipeNavigation, didMoveAtIndex index: UInt)
    {
        if index == 0
        {
//            self.openSlideMenu()
            index == 3
            
        }
    }
    
    /** Show Alter View Network*/
    func ShowAlterViewController(titleInput: String , message: String)
    {
        let alert = UIAlertController(title: titleInput,message: message,preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title:cancel, style: UIAlertActionStyle.Default, handler: nil))
        presentViewController(alert, animated: true, completion: nil)
    }
    
    /** Get DeviceId */
    func getDeviceId()
    {
        let userDefaults = NSUserDefaults.standardUserDefaults()
        
        if userDefaults.objectForKey(deviceID) == nil {
            let UUID = NSUUID().UUIDString
            userDefaults.setObject(UUID, forKey: deviceID)
            userDefaults.synchronize()
        }
        if let DeviceID =  NSUserDefaults.standardUserDefaults().valueForKey(deviceID)
        {
            device = DeviceID as! String
        }
    }
    
    /** QR Code Server ID*/
    func serverId(serverID : String)
    {
        self.updatePlayQueueFromClient()
    
         server = serverID
    
    }

/* Udp Broadcast Server */
func UdpBroadcastserver(){
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0),
                   { () -> Void in
                    
                    self.updatePlayQueueFromClient()
                    self.updateCurrentSongPlayingFromClient()
                    
                    let server:UDPServer=UDPServer(addr:"",port:7777)
                    
                    let run:Bool=true
                    
                    while run{
                        let (data,_,_) = server.recv(1024)
                        
                        if let d=data{
                            
                            if let str=String(bytes: d, encoding: NSUTF8StringEncoding)
                            {
                                let jsonStr =  self.convertStringToDictionary(str)
                                
                                print("=== START === \n",jsonStr)
                                
                                if let type = jsonStr!["type"] as? Int {
                                    switch type
                                    {
                                    case COMMAND_TYPE_SERVER_UPDATE_PLAY_QUEUE:
                                        
                                        if  let queueList = jsonStr!["play_queue_list"] as? String
                                        {
                                            self.queue.playQueueList(queueList)
                                        }
                                        
                                    case COMMAND_TYPE_SERVER_UPDATE_CURRENT_SONG_PLAYING:
                                        if  let title = jsonStr!["title"] as? String{
                                            if let id = jsonStr!["id"] as? String{
                                                
                                                self.queue.titleSong(title)
                                                self.queue.upateCurrentImage(id)
                                            }
                                        }
                                    case COMMAND_TYPE_SERVER_UPDATE_CURRENT_SONG_STATUS:
                                        
                                        if let current = jsonStr!["current_song_status"] as? Int
                                        {
                                            self.queue.updateCurrentSongsList(current)
                                        }
                                        
                                    case COMMAND_TYPE_SERVER_NOTIFY_SERVER_AVAILABLE_FROM_SERVER:
                                        
                                        print("Server")
                                    case COMMAND_TYPE_SERVER_EXIT_APP:
                                        //TODO : reset all view of playqueue list.
                                        print("")
                                        
                                    default:
                                        print("\(type)")
                                    }
                                }
                            }
                        }
                    }
    })
}

/** Convert String To Dictionary */
func convertStringToDictionary(text: String) -> [String:AnyObject]?
{
    if let data = text.dataUsingEncoding(NSUTF8StringEncoding) {
        do {
            return try NSJSONSerialization.JSONObjectWithData(data,
                                                              options: []) as? [String:AnyObject]
        }
        catch let error as NSError
        {
            print(error)
        }
    }
    return nil
}

/** Call Server With JSON Parameter */
func callToServerWithStringParameter(param: String)
{
    let clientB:UDPClient = UDPClient(addr: "255.255.255.255", port: 7777)
    clientB.enableBroadcast()
    clientB.send(str: param)
    clientB.close()
}


/** Select Song Client 0*/
func selectSongFromClient(title: String!, id: String!, server_id: String!,
                          device_id:String!)
{
    CommonSerachViewController(COMMAND_TYPE_CLIENT_SELECT_VIDEO,
                               title: title!, id: id, server_id: server_id,
                               device_id: device)
}
/** Select Video Top Client 1*/
func selectTopVideoFromClient(title: String!, id: String!) {
    CommonSerachViewController(COMMAND_TYPE_CLIENT_SELECT_TOP_VIDEO,
                               title: title, id: id, server_id: server,
                               device_id: device)
}

/** Play Video From Play Queue 2*/
func playVideoFromPlayQueue(){
    CommonSerachViewController(COMMAND_TYPE_CLIENT_PLAY_VIDEO_FROM_PLAY_QUEUE, title: null, id: null, server_id: server, device_id: device)
}

/**  Next Video Client 3*/
func nextVideoFromClient(){
    CommonSerachViewController(COMMAND_TYPE_CLIENT_NEXT_VIDEO,
                               title: null, id: null, server_id: server,
                               device_id:device)
}

/** Play Pause Clien 4*/
func playPlause() {
    CommonSerachViewController(COMMAND_TYPE_CLIENT_PLAY_PAUSE,
                               title: null, id: null, server_id: server,
                               device_id: device)
}

/** Update Play Queue Client 5*/
func updatePlayQueueFromClient(){
    CommonSerachViewController(COMMAND_TYPE_CLIENT_UPDATE_PLAY_QUEUE,
                               title: null, id: null, server_id: server,
                               device_id:device)
}

/** Remove Video Client 6*/
func removeFromClient(id: String!,pos : Int!)
{
    CommonSerachViewController(COMMAND_TYPE_CLIENT_REMOVE_VIDEO_FROM_PLAY_QUEUE,
                               title: null, id: id, server_id: server,
                               device_id:device)
    
}


/** Chane Priority Play Queue 7*/
func chanePriorityPlayQueue(id: String!){
    CommonSerachViewController(COMMAND_TYPE_CLIENT_CHANGE_PRIORITY_PLAY_QUEUE, title: null, id: id, server_id: server, device_id: device)
}


/** Play Now Video Client 10*/
func playNowFromClient(title: String!, id: String!)
{
    CommonSerachViewController(COMMAND_TYPE_CLIENT_PLAY_NOW,
                               title: title, id:id, server_id: server,
                               device_id:device)
}


/** Update Current Song Playing Client 11*/
func updateCurrentSongPlayingFromClient()
{   CommonSerachViewController(COMMAND_TYPE_CLIENT_UPDATE_CURRENT_SONG_PLAYING,
                               title: null, id: null, server_id: server,
                               device_id: device)
}

/** Check Server AVAIBLE 12*/
func checkServerAvaiable() {
    CommonSerachViewController(COMMAND_TYPE_CLIENT_CHECK_SERVER_AVAILABLE, title: null, id: null, server_id: server, device_id: device)
}


/** Chane Quality 13*/
func chaneQualityFromClient()
{
    CommonSerachViewController(COMMAND_TYPE_CLIENT_CHANGE_QUALITY, title: null,
                               id: null, server_id: server, device_id: device)
}

/** Check Current Song Status 14*/
func checkCurrentSongStatusFromClient(){
    CommonSerachViewController(COMMAND_TYPE_CLIENT_CHECK_CURRENT_SONG_STATUS,
                               title: null, id: null, server_id: server,
                               device_id: device)
}


/** Call func getDataFromAnotehrVC */
func callFunc(){
    
    let strParam = CommonSerachViewController(0 ,title:  null,  id: null,
                                              server_id: server,  device_id: device)
    callToServerWithStringParameter(strParam)
}

/** Common Search View Controller  */
func CommonSerachViewController(type:Int!, title : String!,
                                id: String!,server_id: String!,device_id: String!) -> String
{
    let myDictOfDict:NSDictionary = [ "type" :type, "title" : title,
                                      "id": id,"server_id":server,"device_id":device,"pos":0]
    let jsonData = try! NSJSONSerialization.dataWithJSONObject(myDictOfDict, options: [])
    let jsonString = NSString(data: jsonData, encoding: NSUTF8StringEncoding) as! String
    callToServerWithStringParameter(jsonString)
    return jsonString
}


/** Call Notification to Class */
func reviceListSongData(notifaction: NSNotification) {
    let listString = notifaction.object
    self.stringList.addObject(listString!)
    SongList.sharedInstance.lisArraySong = self.stringList
}

}
