//
//  DataService.swift
//  KaraokeApp
//
//  Created by SOSO on 9/6/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import Foundation
import Alamofire

class DataService {
    
    func getVideoHD(url: String, handle: (dict: [NSDictionary]) -> ())
    {
        Alamofire.request(.GET, url, parameters: nil)
            .responseJSON{ response in
                switch response.result {
                case .Success:
                    let statusCode: Int = response.response!.statusCode
                    
                    if statusCode == 200 {
                        guard let jsonString = response.result.value else {
                            return
                        }
                        if let songsDictionary = jsonString["items"] as? [NSDictionary] {
                            handle(dict: songsDictionary)
                        }
                    }else if statusCode == 404 {
                        print("Not Data ")
                    }else {
                        print( " Errer !")
                    }
                    
                case .Failure:
                    print(" Errer ")
                }
        }
    }
}