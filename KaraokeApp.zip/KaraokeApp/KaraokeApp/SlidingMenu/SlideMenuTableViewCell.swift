//
//  SlideMenuTableViewCell.swift
//  
//  Created by SOSO on 7/29/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//


import UIKit

class SlideMenuTableViewCell: UITableViewCell {

    @IBOutlet var imageV: UIImageView!
    @IBOutlet var lblDetail: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.borderColor = UIColor.whiteColor().CGColor
        self.layer.borderWidth = 5
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
