//
//  TCPConnection.swift
//  KaraokeApp
//
//  Created by SOSO on 9/1/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import UIKit

class TCPConnection: NSObject {
    
    let comp = "TCPConnection"
    
    var connected = false
    let name : String
    let port : UInt32
    var readStream: NSInputStream? = nil
    var writeStream: NSOutputStream? = nil
    var openConnections = Set<NSStream>()
    
    
    
    //CWConnection
    public var delegate: CWConnectionDelegate?
    
    internal required init(name theName : String, port thePort : UInt32, background theBool: Bool)
    {
        assert(theBool == true,"Only asynchronous connections inbackgrounf are supported")
        name = theName
        port = thePort
        super.init()
    }
    
    
    func setupStrem(stream: NSStream?)
    {
        stream?.delegate = self
        stream?.setProperty(NSStreamSocketSecurityLevelNegotiatedSSL, forKey: NSStreamSocketSecurityLevelKey)
        stream?.scheduleInRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
        stream?.open()
    }
    
    func closeAndRemoveStream(stream: NSStream?)
    {
        if let theStream = stream
        {
            theStream.close()
            openConnections.remove(theStream)
            if theStream == readStream {
                readStream = nil
            }else if theStream == writeStream
            {
                writeStream = nil
            }
        }
    }
    
    func  writeOutBuffer() -> Int {
        return 0
    }
}

extension TCPConnection: CWConnection
{
    internal func isConnected() -> Bool
    {
        return connected
    }
}

public func close()
{
    closeAndRemoveStream(readStream)
    closeAn
}
