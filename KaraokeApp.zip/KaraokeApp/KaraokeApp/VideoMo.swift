//
//  VideoMo.swift
//  KaraokeApp
//
//  Created by SOSO on 9/6/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import Foundation
class VideoMo {
        
    
    
}
