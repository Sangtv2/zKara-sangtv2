//
//  GeneralClass.swift
//  KaraokeApp
//
//  Created by SOSO on 8/28/16.
//  Copyright © 2016 Sangtv2. All rights reserved.
//

import Foundation


let height: CGFloat = 90

var server = ""
var device = ""

let deviceID = "deviceID"
let keyServerId = "keyCode"

/** KR Serach  */
let apiKey = "AIzaSyB1UWPSS2uhXEoGFN_vJJYY9kjzJe_bC-o"
let keySearch = " Nhập tên ca khúc hoặc ca sĩ "
let message =  " Không tìm thấy nội dung ! "
let messagekn = " Kiểm tra kết nối mạng !"

/** KR Top */
let urlTop = "https://www.googleapis.com/youtube/v3/search?part=snippet&order=viewCount&maxResults=50&type=video&q=beat+intitle:karaoke&key=AIzaSyCojCp66RLS9OY8hOwnW0UWLNdC56z24Os"

let urlTopHD = "https://www.googleapis.com/youtube/v3/videos?key=AIzaSyCojCp66RLS9OY8hOwnW0UWLNdC56z24Os&fields=items(snippet(title,thumbnails),statistics,contentDetails)&part=snippet,statistics,contentDetails&id=qu_25HafHOk"


/** Title */

let MENU = " MENU SEARCH"
let MenuTop = " MENU TOP "
let MenuLike = " MENU LIKE "
let MenuQueue = " MENU PLAY QUEUE "

let addplaySong =  "Thêm Ca Khúc"
let addTop =  "Thêm Vào Đầu"
let Cancel = " Huỷ bỏ "
let Delete = "Xoá"
let null = ""
let likeVC = "likeVC"
let type = "type"

let play_queue_list = "play_queue_list"
let current_song_status = "current_song_status"

let titleCount = "Danh Sách Chờ "
let urlTitle = "https://www.youtube.com/watch?v="
let thumbImage = "http://img.youtube.com/vi/"
let playnow = "Phát Ngay"
let Futura = "Futura"
let like = "Yêu Thích"
let titles  = "title"
let jpg = "/0.jpg"
let menu = "menu"

let ic_arrow_right = "ic_arrow_right"
let ic_arrow_left = "ic_arrow_left"
let cancel = " ❌ "



