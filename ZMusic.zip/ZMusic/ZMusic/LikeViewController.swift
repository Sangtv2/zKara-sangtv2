//
//  LikeViewController.swift
//  ZMusic
//
//  Created by SOSO on 9/17/16.
//  Copyright © 2016 SANGTRIEU. All rights reserved.
//

import UIKit

class LikeViewController: UIViewController {
       
}
