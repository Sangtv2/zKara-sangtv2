//
//  TopViewController.swift
//  ZMusic
//
//  Created by SOSO on 9/17/16.
//  Copyright © 2016 SANGTRIEU. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation
import MBProgressHUD
import youtube_parser
import SDWebImage

class TopViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    let urlTop = "https://www.googleapis.com/youtube/v3/search?part=snippet&order=viewCount&maxResults=50&type=video&q=luyen+nghe+JLPT&key=AIzaSyCojCp66RLS9OY8hOwnW0UWLNdC56z24Os"
    
    var listTopSong : [SongDetail] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchData()
        
        self.tableView.registerNib(UINib.init(nibName: "CustomTableViewCell", bundle: nil), forCellReuseIdentifier: "CustomTableViewCell")
    }
    
    func fetchData()
    {
        let loadingNotification = MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        loadingNotification.mode = MBProgressHUDMode.Indeterminate
        loadingNotification.tintColor = UIColor.lightGrayColor()
        DataService().getVideo(self.urlTop, handle: self.handleReturnValue)
    }
    
    func handleReturnValue(dict: [NSDictionary]) {
        
        for dict in dict {
            let song = SongDetail(dict: dict)
            listTopSong.append(song)
        }
        tableView.reloadData()
        MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return listTopSong.count
    }
    
    /* CellForRowAtIndexPath*/
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell : CustomTableViewCell = tableView.dequeueReusableCellWithIdentifier("CustomTableViewCell", forIndexPath: indexPath) as! CustomTableViewCell
        
        let detailStrong:SongDetail = listTopSong[indexPath.row]
        
        cell.titleName.text = detailStrong.title
        cell.imgView.sd_setImageWithURL(NSURL.init(string: (detailStrong.thumbnail.defaults?.url)!), completed: nil)
        
        return cell
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        let id:SongDetail = listTopSong[indexPath.row]
        let videoID = id.videoID.videoId
        let link = "https://www.youtube.com/watch?v=\(videoID)"
        print(link)
        let videoURL = NSURL(string: link)
        let player = AVPlayer(URL: videoURL!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.presentViewController(playerViewController, animated: true) {
            playerViewController.player!.play()
        }
    }
    
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 70
    }
}
