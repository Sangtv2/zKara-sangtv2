//
//  SongList.swift
//  ZMusic
//
//  Created by SOSO on 9/17/16.
//  Copyright © 2016 SANGTRIEU. All rights reserved.
//

import Foundation

class SongList: NSObject {
    
    var listTopSongs : [SongDetail] = []
    
    class var shareInstance: SongList {
        struct Static {
            static var onceToken: dispatch_once_t = 0
            static var instance : SongList? = nil
        }
        dispatch_once(&Static.onceToken)
        {
            Static.instance = SongList()
        }
        return Static.instance!
    }
    
    func getSongList(dicts: [NSDictionary])
    {
        for dict in dicts
        {
            let song = SongDetail(dict: dict)
            listTopSongs.append(song)
        }
    }
    
}
