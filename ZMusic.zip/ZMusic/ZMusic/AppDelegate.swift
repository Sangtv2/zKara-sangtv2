//
//  AppDelegate.swift
//  ZMusic
//
//  Created by SOSO on 9/17/16.
//  Copyright © 2016 SANGTRIEU. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
        self.window = UIWindow.init(frame: UIScreen.mainScreen().bounds)
        self.window!.makeKeyAndVisible()
        let tabController:FNFoldingTabBarController = FNFoldingTabBarController.init()
        tabController.title = " JLPT  "
        tabController.tabBarBgColor = UIColor.clearColor()
        let TopVC = TopViewController.init()
        TopVC.tabBarItem.title = "TopVC";
        TopVC.tabBarItem.image = nil
        
        let SearchVC = SearchViewController.init()
        SearchVC.tabBarItem.title = "SearchVC";
        SearchVC.tabBarItem.image = nil
        
        
        let LikeVC = LikeViewController.init()
        LikeVC.tabBarItem.title = "LikeVC";
        LikeVC.tabBarItem.image = nil
        
        let QueueVC = QueueViewController.init()
        QueueVC.tabBarItem.title = "QueueVC";
        QueueVC.tabBarItem.image = nil
        
        tabController.fn_viewControllers=[SearchVC, TopVC, LikeVC, QueueVC]
        
        let naviController = UINavigationController.init(rootViewController: tabController)
        self.window!.rootViewController = naviController
        self.window!.makeKeyAndVisible()
        
        return true
    }

    func applicationWillResignActive(application: UIApplication) {
      
    }

    func applicationDidEnterBackground(application: UIApplication) {
       
    }

    func applicationWillEnterForeground(application: UIApplication) {
    
    }

    func applicationDidBecomeActive(application: UIApplication) {
   
    }

    func applicationWillTerminate(application: UIApplication) {
    
    }


}

