//
//  SongDetail.swift
//  ZMusic
//
//  Created by SOSO on 9/17/16.
//  Copyright © 2016 SANGTRIEU. All rights reserved.
//

import Foundation

class SongDetail {
    
    var channelTitle :String!
    var thumbnail:Thumbnail!
    var title:String!
    var videoID:VideoID!
    var pos:Int!
    
    convenience init (dict: NSDictionary) {
        self.init()
        guard let snippet = dict["snippet"] else {
            return
        }
        if let channelTitle = snippet["channelTitle"] as? String {
            self.channelTitle = channelTitle
        }
        if let title = snippet["title"] as? String {
            self.title = title
        }
        if let videoID = dict["id"] as? NSDictionary {
            self.videoID = VideoID(from: videoID)
        }
        if let thumbnaill = snippet["thumbnails"] as? NSDictionary{
            thumbnail = Thumbnail(dict: thumbnaill)
        }
        
        
        func toDictionary()-> NSDictionary {
            let dictionary = NSMutableDictionary()
            if channelTitle != nil {
                dictionary["channelTitle"] = channelTitle
            }
            if videoID != nil {
                dictionary["id"] = videoID.toDictionary()
            }
            
            if thumbnail != nil {
                dictionary["width"] = thumbnail.toDictionary()
            }
            
            return dictionary
        }
    }
    
}
class VideoID {
    var kind: String!
    var videoId: String!
    
    convenience init(from dict: NSDictionary)
    {
        self.init()
        
        if let videoId = dict["videoId"] as? String {
            self.videoId = videoId
        }
    }
    
    func toDictionary() -> NSDictionary {
        let dictionary = NSMutableDictionary()
        if kind != nil {
            dictionary["kind"] = kind
        }
        if videoId != nil {
            dictionary["videoId"] = videoId
        }
        return dictionary
    }
}

class Thumbnail {
    var defaults: ThumbnailSize?
    var medium: ThumbnailSize?
    var high: ThumbnailSize?
    
    convenience init(dict: NSDictionary) {
        self.init()
        if let thumbnaill = dict["default"] as? NSDictionary{
            defaults = ThumbnailSize(from: thumbnaill)
        }
    }
    
    func toDictionary() -> NSDictionary {
        let dictionary = NSMutableDictionary()
        if defaults != nil {
            dictionary["default"] = defaults!.toDictionary()
        }
        if medium != nil {
            dictionary["medium"] = medium?.toDictionary()
        }
        if high != nil {
            dictionary["high"] = high?.toDictionary()
        }
        return dictionary
    }
}

class ThumbnailSize {
    
    var url : String?
    var width: Int?
    var height: Int?
    
    
    convenience init(from dict: NSDictionary) {
        self.init()
        url = dict["url"] as? String
        width = dict["width"] as? Int
        height = dict["height"] as? Int
    }
    
    func toDictionary() -> NSDictionary {
        let dictionary = NSMutableDictionary()
        if url != nil {
            dictionary["url"] = url
        }
        if width != nil {
            dictionary["width"] = width
        }
        if height != nil {
            dictionary["height"] = height
        }
        return dictionary
    }
}