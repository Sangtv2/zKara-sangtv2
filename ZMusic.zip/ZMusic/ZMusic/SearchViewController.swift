//
//  SearchViewController.swift
//  ZMusic
//
//  Created by SOSO on 9/17/16.
//  Copyright © 2016 SANGTRIEU. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation
import MBProgressHUD



class SearchViewController: UIViewController ,UISearchBarDelegate{
    @IBOutlet  var tableview: UITableView!
    @IBOutlet  var searchBar: UISearchBar!
    
    
    var listTopSong : [SongDetail] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.searchBar.delegate = self
        
        self.searchBar.placeholder = " Tìm kiếm "
        self.searchBar.sizeToFit()
        self.searchBar.showsCancelButton = false
        self.definesPresentationContext = true
        self.tableview.registerNib(UINib.init(nibName: "CustomTableViewCell", bundle: nil),
                                   forCellReuseIdentifier: "CustomTableViewCell")
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    func searchBarButtonClick(searchBar: UISearchBar)
    {
        let apiKey = "AIzaSyB1UWPSS2uhXEoGFN_vJJYY9kjzJe_bC-o"
        let jlpt : String  = " JLPT "
        var key : String = searchBar.text! + jlpt
        key = key.stringByReplacingOccurrencesOfString(" ", withString: "+", options: NSStringCompareOptions.LiteralSearch, range: nil)
        let urlSearch = "https://www.googleapis.com/youtube/v3/search?part=snippet&order=viewCount&maxResults=50&type=video&q=\(key)&key=\(apiKey)"
        
        searchBar.resignFirstResponder()
        fetchData()
        DataService().getVideo(urlSearch, handle: handleReturnValue)
        tableview.reloadData()
        
    }
    func fetchData()
    {
        let loadingNotification = MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        loadingNotification.mode = MBProgressHUDMode.Indeterminate
        loadingNotification.color = UIColor.lightGrayColor()
    }
    
    func handleReturnValue(dict: [NSDictionary]) {
        
        for dict in dict {
            let song = SongDetail(dict: dict)
            listTopSong.append(song)
        }
        tableview.reloadData()
        MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
        
    }
    /* Number of Row in Section */
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listTopSong.count
        
    }
    
    /* Cell for row at indexPath */
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell : CustomTableViewCell = tableView.dequeueReusableCellWithIdentifier("CustomTableViewCell", forIndexPath: indexPath) as! CustomTableViewCell
        
        if (listTopSong.count - 1 >= indexPath.row)
        {
            let detailStrong:SongDetail = listTopSong[indexPath.row]
            cell.titleName.text = detailStrong.title
            cell.imgView?.sd_setImageWithURL(NSURL.init(string: (detailStrong.thumbnail.defaults?.url)!), completed: nil)
        }
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        let id:SongDetail = listTopSong[indexPath.row]
        
        let videoID = id.videoID.videoId
        let link = "https://www.youtube.com/watch?v=\(videoID)"
        print(link)
        let videoURL = NSURL(string: link)
        let player = AVPlayer(URL: videoURL!)
        let playerViewController = AVPlayerViewController()
        dispatch_async(dispatch_get_main_queue()) {
            playerViewController.player = player
            self.presentViewController(playerViewController, animated: true)
            {
                playerViewController.player!.play()
            }
        }
    }
    
    /* Height For Row At IndexPath */
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 70
    }
    func searchBar(searchBar: UISearchBar,textDidChange searchText: String)
    {
        self.searchBarButtonClick(searchBar)
        searchBar.becomeFirstResponder()
    }
    
}
