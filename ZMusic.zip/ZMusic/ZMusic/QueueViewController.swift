//
//  QueueViewController.swift
//  ZMusic
//
//  Created by SOSO on 9/17/16.
//  Copyright © 2016 SANGTRIEU. All rights reserved.
//

import UIKit
import MediaPlayer

class QueueViewController: UIViewController {
    var moviePlayer:MPMoviePlayerController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let url:NSURL = NSURL(string: "https://www.youtube.com/watch?v=flfi38e0NKk")!
        {
        moviePlayer = MPMoviePlayerController(contentURL: url)
        moviePlayer.view.frame = CGRect(x: 20, y: 100, width: 200, height: 150)
        
        self.view.addSubview(moviePlayer.view)
        moviePlayer.fullscreen = true
        
        moviePlayer.controlStyle = MPMovieControlStyle.Embedded
        }
    }
}
